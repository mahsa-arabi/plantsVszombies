#ifndef RESTART_H
#define RESTART_H

#include <QGraphicsPixmapItem>

#include <Controller/controller.h>



class ReStart : public QGraphicsPixmapItem
{
private:
   // Controller* controller;
public:
    ReStart();
};

#endif // RESTART_H
