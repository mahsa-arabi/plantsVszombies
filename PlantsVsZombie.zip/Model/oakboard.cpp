#include "ground.h"
#include "oakBoard.h"
#include <iostream>

OakBoard::OakBoard(QGraphicsScene *scene,Score* score,QList<Ground*> blocks):score{score}
  ,blocks{blocks}
{
    setPixmap(QPixmap(":/images/oakBord1.png"));
    setPos(170,8);

     this->scene=scene;
     scene->addItem(this);
}

void OakBoard::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    isSelected=!isSelected;
   if(score->getScore() >= 50 && isSelected){
      setPixmap(QPixmap(":/images/aokBord2.png"));

          score->decreseScore(50);

         for (int i=0;i<8;++i) {
             blocks[i]->isOakSelectable=true;
         }
   }else
       setPixmap(QPixmap(":/images/oakBord1.png"));
}

