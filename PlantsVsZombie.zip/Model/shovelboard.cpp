#include "shovelboard.h"
#include "ground.h"

ShovelBoard::ShovelBoard(QGraphicsScene * scene,Score* score,QList<Ground*> blocks)
    :score{score},blocks{blocks}
{
   setPixmap(QPixmap(":/images/shovelBoard1.jpg"));
   setPos(340,6);

    this->scene=scene;
    scene->addItem(this);
}

void ShovelBoard::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    isSelected=!isSelected;
   if(isSelected){
      setPixmap(QPixmap(":/images/shovelBoard2.jpg"));

         for (int i=0;i<8;++i) {
             blocks[i]->isShovelSelectable=true;
         }
   }else
       setPixmap(QPixmap(":/images/shovelBoard1.jpg"));

}

