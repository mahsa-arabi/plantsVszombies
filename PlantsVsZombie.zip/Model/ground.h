#ifndef GROUND_H
#define GROUND_H

#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include "Model/oak.h"
#include "Model/bomb.h"

#include "Model/shooterplant.h"
#include "Model/shovel.h"
#include "Model/sunflower.h"
class Ground:public QGraphicsPixmapItem
{
private:
    QGraphicsScene * scene;
    BuyingThings* planted;
    Score* score;
    QList<Ground*> otherBlocks;
    QList<Ground*> nearBlocks;
    int elementNum;
public:

    bool isOakSelectable=false;
    bool isShooterSelectable=false;
    bool isSunFSelectable=false;
    bool isBombSelectable=false;
    bool isShovelSelectable=false;
      bool isPlanted=false;
     Ground(QGraphicsScene * scene,Score* score,int elementNum);
     void mousePressEvent(QGraphicsSceneMouseEvent* event);
    // int findBlock(double x);
     void setOtherBlocks(const QList<Ground *> &value);
     void removePlant();
     void initializeNearBlocks();
};

#endif // GROUND_H
