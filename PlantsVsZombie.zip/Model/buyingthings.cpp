#include "BuyingThings.h"

BuyingThings::BuyingThings()
{

}
