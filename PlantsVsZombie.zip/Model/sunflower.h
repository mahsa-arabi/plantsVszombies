#ifndef SUNFLOWER_H
#define SUNFLOWER_H
#include <QObject>

#include <QTimer>
#include <QGraphicsScene>
#include "buyingthings.h"
#include "sun.h"

class SunFlower:public QObject,public BuyingThings
{
    Q_OBJECT
private:
    QGraphicsScene * scene;
    QTimer* time;
    int level;
public:
    SunFlower(QGraphicsScene * scene);
    ~SunFlower();

public slots:
   void move();
   void sun();

};

#endif // SUNFLOWER_H
