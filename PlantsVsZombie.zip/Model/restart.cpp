#include "restart.h"


ReStart::ReStart()
{
 // controller->scene->addItem(this);
  setPixmap(QPixmap(":/images/restart.png"));
  setPos(300,350);
}
