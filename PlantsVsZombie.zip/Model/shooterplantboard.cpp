#include "shooterplantboard.h"

#include "ground.h"

ShooterPlantBoard::ShooterPlantBoard(QGraphicsScene * scene,Score* score
                                     ,QList<Ground*> blocks)
    :score{score},blocks{blocks}
{
   setPixmap(QPixmap(":/images/ShooterBord1.png"));
   setPos(70,8);

    this->scene=scene;
    scene->addItem(this);
}

void ShooterPlantBoard::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
     isSelected=!isSelected;
   if(score->getScore() >= 50 && isSelected){
      setPixmap(QPixmap(":/images/ShooterBord2.png"));

          score->decreseScore(50);

         for (int i=0;i<8;++i) {
             blocks[i]->isShooterSelectable=true;
         }
   }else
       setPixmap(QPixmap(":/images/ShooterBord1.png"));
}

