#ifndef ZOMBIE_H
#define ZOMBIE_H


#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include <QGraphicsScene>
#include <QException>
class GameOver : public QException
{
public:
    void raise() const override { throw *this; }
    GameOver *clone() const override { return new GameOver(*this); }
};

class Zombie : public QObject,public QGraphicsPixmapItem
{
    Q_OBJECT
protected:
    QGraphicsScene * scene;
    QTimer* zombieTimer;
    int lives;
    int pixPermiliSec;
    int walkLevel;

public:
    Zombie(QGraphicsScene * scene,const int& pixPermiliSec=5,const int& lives=4);
    ~Zombie();
    void shooted();
    void die();
signals:

public slots:
    virtual void moveToLeft();
};


#endif // ZOMBIE_H
