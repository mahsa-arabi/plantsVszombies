
#include "ground.h"
#include <iostream>

void Ground::setOtherBlocks(const QList<Ground *> &value)
{
    otherBlocks = value;
}

void Ground::removePlant()
{
    scene->removeItem(planted);
    delete planted;
    isPlanted=false;
}

Ground::Ground(QGraphicsScene * scene,Score* score,int elementNum){
    setPixmap(QPixmap(":/images/groundS.png"));
    initializeNearBlocks();
     this->elementNum=elementNum;
     this->scene=scene;
    scene->addItem(this);
}

void Ground::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if(!isPlanted && isShooterSelectable){
       auto plant=new ShooterPlant(scene);
       plant->setPos(x(),y());
       scene->addItem(plant);
       isShooterSelectable=false;
      for (int i=0;i<7;i++) {
          otherBlocks[i]->isShooterSelectable=false;
       }
       planted=plant;
       isPlanted=true;
    }else if(!isPlanted && isSunFSelectable){
        auto plant=new SunFlower(scene);
        plant->setPos(x(),y());
        scene->addItem(plant);
        isSunFSelectable=false;
       for (int i=0;i<7;i++) {
           otherBlocks[i]->isSunFSelectable=false;
        }
        planted=plant;
        isPlanted=true;
    }else if(!isPlanted && isOakSelectable){
        auto plant=new Oak(scene);
        plant->setPos(x(),y());
        scene->addItem(plant);
        isOakSelectable=false;
       for (int i=0;i<7;i++) {
           otherBlocks[i]->isOakSelectable=false;
        }
    }else if(!isPlanted && isBombSelectable){
        auto plant=new Bomb(scene);
        plant->setPos(x(),y());
        scene->addItem(plant);
        isBombSelectable=false;
       for (int i=0;i<7;i++) {
           otherBlocks[i]->isBombSelectable=false;
        }
        //planted=plant;
        isPlanted=true;
    }else if(isPlanted && isShovelSelectable){
//         auto plant=new Shovel(scene);
//         plant->setPos(x(),550);
//         scene->addItem(plant);
         isShovelSelectable=false;
        for (int i=0;i<7;i++) {
            otherBlocks[i]->isShovelSelectable=false;
         }
        scene->removeItem(planted);
        delete planted;
        isPlanted=false;
    }

}
void Ground::initializeNearBlocks()
{
    QList<Ground*> nearBlocks;
    if(otherBlocks.count()==7){
        if(elementNum==0){
            nearBlocks.push_back(otherBlocks[elementNum]);
        }else if (elementNum==7) {
            nearBlocks.push_back(otherBlocks[elementNum-1]);
        }else {
            nearBlocks.push_back(otherBlocks[elementNum-1]);
            nearBlocks.push_back(otherBlocks[elementNum]);
         }

    }else if(otherBlocks.count()==15){
        if(elementNum==0){
            nearBlocks.push_back(otherBlocks[0]);
            nearBlocks.push_back(otherBlocks[7]);
            nearBlocks.push_back(otherBlocks[8]);
        }else if (elementNum==7) {
            nearBlocks.push_back(otherBlocks[6]);
            nearBlocks.push_back(otherBlocks[13]);
            nearBlocks.push_back(otherBlocks[14]);
        }else if (elementNum==8) {
            nearBlocks.push_back(otherBlocks[0]);
            nearBlocks.push_back(otherBlocks[1]);
            nearBlocks.push_back(otherBlocks[8]);
        }else if (elementNum==14) {
            nearBlocks.push_back(otherBlocks[6]);
            nearBlocks.push_back(otherBlocks[7]);
            nearBlocks.push_back(otherBlocks[13]);
        }else {
            nearBlocks.push_back(otherBlocks[elementNum]);
            nearBlocks.push_back(otherBlocks[elementNum+1]);
            if(elementNum < 7){
                for (int i=0; i<3 ;++i) {
                    nearBlocks.push_back(otherBlocks[elementNum+7+i]);
                }
            }else {
                for (int i=0; i<3 ;++i) {
                    nearBlocks.push_back(otherBlocks[elementNum-7-i]);
                }
            }
         }
}else if(otherBlocks.count()==23){
    if(elementNum==0){
        nearBlocks.push_back(otherBlocks[0]);
        nearBlocks.push_back(otherBlocks[7]);
        nearBlocks.push_back(otherBlocks[8]);
    }else if (elementNum==7) {
        nearBlocks.push_back(otherBlocks[6]);
        nearBlocks.push_back(otherBlocks[13]);
        nearBlocks.push_back(otherBlocks[14]);
    }else if (elementNum==8) {
        nearBlocks.push_back(otherBlocks[14]);
        nearBlocks.push_back(otherBlocks[15]);
        nearBlocks.push_back(otherBlocks[0]);
        nearBlocks.push_back(otherBlocks[1]);
        nearBlocks.push_back(otherBlocks[8]);
    }else if (elementNum==14) {
        nearBlocks.push_back(otherBlocks[23]);
        nearBlocks.push_back(otherBlocks[22]);
        nearBlocks.push_back(otherBlocks[6]);
        nearBlocks.push_back(otherBlocks[7]);
        nearBlocks.push_back(otherBlocks[13]);
    }else {
        nearBlocks.push_back(otherBlocks[elementNum]);
        nearBlocks.push_back(otherBlocks[elementNum+1]);
        if(elementNum < 7){
            for (int i=0; i<3 ;++i) {
                nearBlocks.push_back(otherBlocks[elementNum+7+i]);
            }
        }else if(elementNum < 15){
            for (int i=0; i<3 ;++i) {
                nearBlocks.push_back(otherBlocks[elementNum-7-i]);
            }
            for (int i=0; i<3 ;++i) {
                nearBlocks.push_back(otherBlocks[elementNum+7+i]);
            }
        }else {
            for (int i=0; i<3 ;++i) {
                nearBlocks.push_back(otherBlocks[elementNum-7-i]);
            }
            }

        }
     }
    this->nearBlocks=nearBlocks;
}
