#include "bomb.h"

Bomb::Bomb(QGraphicsScene * scene)
{
    this->scene=scene;
    scene->addItem(this);
    level=0;
    time=new QTimer;
    connect(time,SIGNAL(timeout()),this,SLOT(shooting()));
    time->start(1000);
}
int Bomb:: getLevel(){
    return level;
}

Bomb::~Bomb()
{
    scene->removeItem(this);
    delete time;
}
void Bomb:: move(){
    level++;

    switch (level) {
    case 1:
        setPixmap(QPixmap(":/images/Bomb1.png"));
        break;
    case 2:
        setPixmap(QPixmap(":/images/Bomb2.png"));
        break;

    }
}
