#ifndef BOSSZOMBIE_H
#define BOSSZOMBIE_H

#include "zombie.h"

class BossZombie : public Zombie
{
private:
    QTimer* bossTimer;
public:
    BossZombie(QGraphicsScene * scene,const int &pixPerMiliSec=5,const int& lives=10);
public slots:
    void moveToLeft()override;
};

#endif // BOSSZOMBIE_H
