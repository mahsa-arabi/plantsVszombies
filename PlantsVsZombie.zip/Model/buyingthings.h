#ifndef BUYINGTHINGS_H
#define BUYINGTHINGS_H

#include <QGraphicsItem>

class BuyingThings : public QGraphicsPixmapItem
{
public:
    BuyingThings();
};

#endif // BUYINGTHINGS_H
