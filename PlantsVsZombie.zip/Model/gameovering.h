#ifndef GAMEOVERING_H
#define GAMEOVERING_H

#include <QObject>
#include <QGraphicsTextItem>
#include <QGraphicsScene>

class GameOvering : public QGraphicsTextItem
  {
public:
    explicit GameOvering();

signals:

};

#endif // GAMEOVERING_H
