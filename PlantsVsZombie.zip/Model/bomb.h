#ifndef BOMB_H
#define BOMB_H
#include "buyingthings.h"

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include <QGraphicsScene>


class Bomb:public QObject,public BuyingThings
{
    Q_OBJECT
private:
    QGraphicsScene * scene;
    QTimer* time;
    int level;
public slots:
    void move();

public:
    Bomb(QGraphicsScene * scene);
    int getLevel();
    void explode();
    ~Bomb();
};

#endif // BOMB_H
