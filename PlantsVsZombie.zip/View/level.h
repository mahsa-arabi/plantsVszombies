#ifndef LEVEL_H
#define LEVEL_H

#include <QGraphicsScene>
#include <QTimer>

#include <Model/BuyingThings.h>
#include <Model/zombie.h>


class Level :public QGraphicsScene
{
   // friend class Controller;
public:
    //Level(QGraphicsScene* scene);
    Level();
    ~Level();
 //   void addZombie(Zombie* z);
protected:
    // QList<Zombie*> zombies;
    int secend=0;
    QTimer* time;
   QGraphicsScene* scene;
   BuyingThings* buyedThings[8];
    int findBlock(double x);
    int findBlock2(double x);
    int findBlock3(double x);
};
#endif // LEVEL_H
