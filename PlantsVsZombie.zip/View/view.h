#ifndef VIEW_H
#define VIEW_H


#include "../Controller/controller.h"
#include <QGraphicsView>
#include <QPushButton>
#include "../Model/gameovering.h"
#include "../Model/bosszombie.h"
#include <QObject>
#include "Model/score.h"
#include "Model/sunflower.h"
#include "Model/shooterplant.h"
#include "../Model/zombie.h"
#include <QMediaPlayer>

class View: public QGraphicsView
{
Q_OBJECT
private:
    Controller* controller;
    int secend=0;
    QTimer* viewTimer;
    QMediaPlayer* backhgroundMusic;
public:
    View();
     void clearScene();
public slots:
    void l1();
    void s2l1();
    void s2l2();
    void s3l1();
    void s3l2();
    void s3l3();
    void plusSecendl1();
    void plusSecends2l1();
    void plusSecends2l2();
    void plusSecends3l1();
    void plusSecends3l2();
    void plusSecends3l3();
};

#endif // VIEW_H
