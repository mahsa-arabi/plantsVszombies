#include "level.h"


//Level::Level(QGraphicsScene* scene)
//{
//    scene=new QGraphicsScene(scene);
//}

Level::Level()
{
    time=new QTimer();

    setSceneRect(0,0,800,750);
}

Level::~Level()
{
    delete scene;
}

//void Level::addZombie(Zombie *z)
//{
//     zombies.push_back(z);
}

int Level::findBlock(double x)
{
        int result=0;
        if(0<=x && x<100){
            result=0;
        }else if (100<=x && x<200) {
           result=1;
        }
        else if (200<=x && x<300) {
            result=2;
        }else if (300<=x && x<400) {
            result=3;
        }else if (400<=x && x<500) {
            result=4;
        }else if (500<=x && x<600) {
            result=5;
        }else if (600<=x && x<700) {
            result=6;
        }else if (700<=x && x<=800) {
            result=7;
        }
        return result;
}
int Level::findBlock2(double x)
{
    int result=-1;
    if(findBlock(x)==-1){

           if(0<=x && x<100){
               result=8;
           }else if (100<=x && x<200) {
              result=9;
           }
           else if (200<=x && x<300) {
               result=10;
           }else if (300<=x && x<400) {
               result=11;
           }else if (400<=x && x<500) {
               result=12;
           }else if (500<=x && x<600) {
               result=13;
           }else if (600<=x && x<700) {
               result=14;
           }else if (700<=x && x<=800) {
               result=15;
       }
    }else{
        result=findBlock(x);
    }

   return result;

}

int Level::findBlock3(double x)
{
    int result=-1;
    if(findBlock(x)!=-1){
        return findBlock(x);
    }   else if (findBlock2(x)!=-1) {
        return findBlock2(x);
    }else {
        if(0<=x && x<100){
                   result=16;
               }else if (100<=x && x<200) {
                  result=17;
               }
               else if (200<=x && x<300) {
                   result=18;
               }else if (300<=x && x<400) {
                   result=19;
               }else if (400<=x && x<500) {
                   result=20;
               }else if (500<=x && x<600) {
                   result=21;
               }else if (600<=x && x<700) {
                   result=22;
               }else if (700<=x && x<=800) {
                   result=23;
           }
   }
    return result;
}
