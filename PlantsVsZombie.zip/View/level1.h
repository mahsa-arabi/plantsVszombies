#ifndef LEVEL1_H
#define LEVEL1_H

#include "level.h"
#include <QPushButton>
#include "Model/score.h"
#include "Model/sunflower.h"
#include "Model/shooterplant.h"
#include "../Controller/controller.h"
#include "../Model/zombie.h"
#include "../Model/gameovering.h"

class level1: public Level
{
    Q_OBJECT
protected:
    
  QPushButton * sp;
  QPushButton * sf;
  QPushButton * sv;
  Score * score;

public:
    //level1(Controller* controller);
    level1();
public slots:
    void on_sf_clicked(QMouseEvent  event);
    void on_sv_clicked(QMouseEvent  event);
    void on_sp_clicked(QMouseEvent  event);
    void plusSecend();
    int findBlock(double x);


};


#endif // LEVEL1_H
