#include "level1.h"

#include <QMouseEvent>
#include <QObject>
#include <QException>
#include "s2level1.h"



//level1::level1(Controller* controller) :Level(controller->scene),controller{controller}
//{
//   setBackgroundBrush(QBrush(QImage(":/images/BackGround 1.png")));
//   sp=new QPushButton();
//   sp->setGeometry(61,0,52,76);
//   sf=new QPushButton();
//   sf->setGeometry(113,0,52,76);
//   sv=new QPushButton();
//   sv->setGeometry(331,0,52,76);
//   connect(sf,SIGNAL(clicked(bool)),this,SLOT(on_sf_clicked(QMouseEvent  event)));
//   connect(sp,SIGNAL(clicked(bool)),this,SLOT(on_sp_clicked(QMouseEvent  event)));
//   connect(sv,SIGNAL(clicked(bool)),this,SLOT(on_sv_clicked(QMouseEvent  event)));
//   connect(time,SIGNAL(timeout()),this,SLOT(plusSecend()));
//}


level1::level1() :Level()
{
   setBackgroundBrush(QBrush(QImage(":/images/BackGround 1.png")));
   sp=new QPushButton();
   sp->setGeometry(61,0,52,76);
   sf=new QPushButton();
   sf->setGeometry(113,0,52,76);
   sv=new QPushButton();
   sv->setGeometry(331,0,52,76);
   connect(sf,SIGNAL(clicked(bool)),this,SLOT(on_sf_clicked(QMouseEvent  event)));
   connect(sp,SIGNAL(clicked(bool)),this,SLOT(on_sp_clicked(QMouseEvent  event)));
   connect(sv,SIGNAL(clicked(bool)),this,SLOT(on_sv_clicked(QMouseEvent  event)));
   time->start(1000);
  connect(time,SIGNAL(timeout()),this,SLOT(plusSecend()));

}
void level1::on_sf_clicked(QMouseEvent  event)
{
    if(-700<=event.y()&& event.y()<-550 && score->getScore() >= 50 ){
         auto flower=new SunFlower(scene);
         int a=findBlock(event.x());
         if(buyedThings[a]==nullptr){
         buyedThings[a]=flower;
         flower->setPos((50+100*a),-700);
         score->decreseScore(50);
         scene->addItem(flower);}
    }
}

void level1::on_sv_clicked(QMouseEvent event)
{
    if(-700<=event.y()&& event.y()<-550 && score->getScore() >= 50 ){
         int a=findBlock(event.x());
         if(buyedThings[a]!=nullptr){
         scene->removeItem(buyedThings[a]);
         delete [] buyedThings[a];
         buyedThings[a]=nullptr;
         }
    }
}


void level1::on_sp_clicked(QMouseEvent  event)
{
    if(-700<=event.y()&& event.y()<-550 && score->getScore() >= 100 ){
         auto plant=new ShooterPlant(scene);
         int a=findBlock(event.x());
         if(buyedThings[a]==nullptr){
         buyedThings[a]=plant;
         plant->setPos((50+100*a),-700);
         score->decreseScore(100);
         scene->addItem(plant);}
    }
    
}

void level1::plusSecend()
{
    try{
    ++secend;
    if(secend==5||secend==54||secend==57||secend==59||secend==60){
        auto z=new Zombie(this);
        addZombie(z);
        z->setPos(800,500);

//     for(auto p : controller->plants)
//        if(p->y()<=700&&p->y()>550){
//            p->shooting1();
//            controller->isShoot=true;
//            controller->shoot(p);
//        }

//    }
//    if(secend==68){
//        controller->scene->clear();
//       auto l=new S2Level1();
   }
}catch(GameOver e){
       // controller->isGameOver=true;
       addItem(new GameOvering());
    }}
int level1::findBlock(double x)
{
        int result=-1;
        if(0<=x && x<100){
            result=0;
        }else if (100<=x && x<200) {
           result=1;
        }
        else if (200<=x && x<300) {
            result=2;
        }else if (300<=x && x<400) {
            result=3;
        }else if (400<=x && x<500) {
            result=4;
        }else if (500<=x && x<600) {
            result=5;
        }else if (600<=x && x<700) {
            result=6;
        }else if (700<=x && x<=800) {
            result=7;
        }
        return result;
}
