#include "view.h"
#include <QScrollBar>
#include <Model/bombboard.h>
#include <Model/oakboard.h>

#include <Model/restart.h>
#include <Model/shooterplantboard.h>
#include <Model/shovelboard.h>
#include <Model/sunflowerboard.h>
#include <iostream>

View::View()
{
    viewTimer=new QTimer();
    controller=new Controller();
    setScene(controller->scene);
    setFixedSize(800,750);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    controller->scene->addItem(controller->score);
    //add background music
    backhgroundMusic=new QMediaPlayer();
    backhgroundMusic->setMedia(QUrl("qrc:/sounds/backGroundSound.mpeg"));
    backhgroundMusic->play();

    viewTimer->start(1000);

    l1();

}


void View::l1()
{
    setBackgroundBrush(QBrush(QImage(":/images/BackGround 1.png")));
    controller->addBlocks(1);
    auto sp=new ShooterPlantBoard(controller->scene,controller->score,controller->blocks);
    auto sf=new SunFlowerBoard(controller->scene,controller->score,controller->blocks);
    auto shovel=new ShovelBoard(controller->scene,controller->score,controller->blocks);
    connect(viewTimer,SIGNAL(timeout()),this,SLOT(plusSecendl1()));
}

void View::s2l1()
{
     setBackgroundBrush(QBrush(QImage(":/images/BackGround 2.png")));
     controller->addBlocks(2);
   auto sp=new ShooterPlantBoard(controller->scene,controller->score,controller->blocks);
   auto sf=new SunFlowerBoard(controller->scene,controller->score,controller->blocks);
 //  auto shovel=new ShovelBoard(controller->scene,controller->score,controller->blocks);
   auto oak=new OakBoard(controller->scene,controller->score,controller->blocks);
     connect(viewTimer,SIGNAL(timeout()),this,SLOT(plusSecends2l1()));
}
void View::s2l2()
{
    setBackgroundBrush(QBrush(QImage(":/images/BackGround 2.png")));
     controller->addBlocks(2);
     auto sp=new ShooterPlantBoard(controller->scene,controller->score,controller->blocks);
     auto sf=new SunFlowerBoard(controller->scene,controller->score,controller->blocks);
   //  auto shovel=new ShovelBoard(controller->scene,controller->score,controller->blocks);
     auto oak=new OakBoard(controller->scene,controller->score,controller->blocks);
    connect(viewTimer,SIGNAL(timeout()),this,SLOT(plusSecends2l2()));
}

void View::s3l1()
{
    setBackgroundBrush(QBrush(QImage(":/images/BackGround 3.png")));
    controller->addBlocks(3);
    auto sp=new ShooterPlantBoard(controller->scene,controller->score,controller->blocks);
    auto sf=new SunFlowerBoard(controller->scene,controller->score,controller->blocks);
  //  auto shovel=new ShovelBoard(controller->scene,controller->score,controller->blocks);
    auto oak=new OakBoard(controller->scene,controller->score,controller->blocks);
     auto bomb=new BombBoard(controller->scene,controller->score,controller->blocks);
    connect(viewTimer,SIGNAL(timeout()),this,SLOT(plusSecends3l1()));
}

void View::s3l2()
{
    setBackgroundBrush(QBrush(QImage(":/images/BackGround 3.png")));
    controller->addBlocks(3);
    auto sp=new ShooterPlantBoard(controller->scene,controller->score,controller->blocks);
    auto sf=new SunFlowerBoard(controller->scene,controller->score,controller->blocks);
  //  auto shovel=new ShovelBoard(controller->scene,controller->score,controller->blocks);
    auto oak=new OakBoard(controller->scene,controller->score,controller->blocks);
    auto bomb=new BombBoard(controller->scene,controller->score,controller->blocks);
    connect(viewTimer,SIGNAL(timeout()),this,SLOT(plusSecends3l2()));
}

void View::s3l3()
{
    setBackgroundBrush(QBrush(QImage(":/images/BackGround 3.png")));
    controller->addBlocks(3);
 auto sp=new ShooterPlantBoard(controller->scene,controller->score,controller->blocks);
    auto sf=new SunFlowerBoard(controller->scene,controller->score,controller->blocks);
  //  auto shovel=new ShovelBoard(controller->scene,controller->score,controller->blocks);
    auto oak=new OakBoard(controller->scene,controller->score,controller->blocks);
    auto bomb=new BombBoard(controller->scene,controller->score,controller->blocks);
    connect(viewTimer,SIGNAL(timeout()),this,SLOT(plusSecends3l3()));
}

void View::plusSecendl1()
{
    try{
    ++secend;
        if(secend%2==0){
            auto sun=new Sun(controller->scene,controller->score,controller->holder,viewTimer);
             controller->score->setPlainText(QString::number(controller->score->getScore()));
        }
   if(secend==5||secend==54||secend==57||secend==59||secend==60){
       auto z=new Zombie(controller->scene);
       controller->addZombie(z);
       z->setPos(800,500);
    }
    if(secend==68){
        clearScene();
        s2l1();}

}catch(GameOver e){
    // controller->isGameOver=true;
         std::cout << "hi" <<std::endl;
        auto g=new GameOvering();
    controller->scene->addItem(g);
    g->setPos(200,170);
    int timeOfGameOver=secend;
    if(secend==timeOfGameOver+4){
        l1();
    }
 }
}
void View::plusSecends2l1()
{
     try {
          ++secend;
          int a=rand();
          if(secend%10==0){
              auto sun=new Sun(controller->scene,controller->score,controller->holder,viewTimer);
               controller->score->setPlainText(QString::number(controller->score->getScore()));
          }
          if(secend==50||secend==58||secend==62||secend==63){
              auto z=new Zombie(controller->scene);
              controller->addZombie(z);
              if(a%2==0)
                 {
                  z->setPos(800,700);
              }
              else{ z->setPos(800,550);
                  }
          }
          if(secend==55||secend==60||secend==63||secend==64){
              auto z=new Zombie(controller->scene);
              controller->addZombie(z);
              if(a%2==0)
                 {
                  z->setPos(800,550);
                 }
              else{ z->setPos(800,700);
                }
          }
          if(secend==73){
              clearScene();
              s2l2();
          }
      }catch(GameOver e){
        auto g=new GameOvering();
    controller->scene->addItem(g);
    g->setPos(200,170);
    int timeOfGameOver=secend;
    if(secend==timeOfGameOver+4){
        s2l1();
    }
  }

}

void View::plusSecends2l2()
{
      try {
           ++secend;
        if(secend%10==0){
            auto sun=new Sun(controller->scene,controller->score,controller->holder,viewTimer);
             controller->score->setPlainText(QString::number(controller->score->getScore()));
        }
           int a=rand();
           if(secend==45||secend==48||secend==50||secend==52||secend==51){
               auto z=new Zombie(controller->scene);
               controller->addZombie(z);
               if(a%2==0)
               { z->setPos(800,700);
            }
            else{ z->setPos(800,550);
                }
           }
           if(secend==48||secend==49||secend==50||secend==51||secend==52){
               auto z=new Zombie(controller->scene);
               controller->addZombie(z);
               if(a%2==0)
               { z->setPos(800,550);
               }
            else{ z->setPos(800,700);
               }
           }
           if(secend==61){
               clearScene();
               s3l1();
           }
       }catch(GameOver e){
        auto g=new GameOvering();
    controller->scene->addItem(g);
    g->setPos(200,170);
    int timeOfGameOver=secend;
    if(secend==timeOfGameOver+4){
        s2l2();
    }
       }

}

void View::plusSecends3l1()
{
     try {
          ++secend;
          int a=rand();
          if(secend%10==0){
              auto sun=new Sun(controller->scene,controller->score,controller->holder,viewTimer);
               controller->score->setPlainText(QString::number(controller->score->getScore()));
          }
          if(secend==40||secend==48||secend==50||secend==47){
              auto z=new Zombie(controller->scene);
              controller->addZombie(z);
              z->setPos(800,550);

          }
          if(secend==44||secend==47||secend==50||secend==51){
              auto z=new Zombie(controller->scene);
              controller->addZombie(z);

              z->setPos(800,700);

          }
          if(secend==46||secend==48||secend==50||secend==51){
              auto z=new Zombie(controller->scene);
              controller->addZombie(z);
              z->setPos(800,400);

          }
          if(secend==53){
              auto bz1=new BossZombie (controller->scene);
              controller->addBossZombie(bz1);
              bz1->setPos(800,400);
              auto bz2=new BossZombie (controller->scene);
              controller->addBossZombie(bz2);
              bz1->setPos(800,550);
              auto bz3=new BossZombie (controller->scene);
              controller->addBossZombie(bz3);
              bz3->setPos(800,700);

          }
          if(secend==62){
              clearScene();
              s3l2();
          }
      }catch(GameOver e){
        auto g=new GameOvering();
    controller->scene->addItem(g);
    g->setPos(200,170);
    int timeOfGameOver=secend;
    if(secend==timeOfGameOver+4){
       s3l1();
    }
      }
}

void View::plusSecends3l2()
{

   try  {
         ++secend;
         int a=rand();
         if(secend%10==0){
             auto sun=new Sun(controller->scene,controller->score,controller->holder,viewTimer);
              controller->score->setPlainText(QString::number(controller->score->getScore()));
         }
         if(secend==40||secend==48||secend==50||secend==47){
             auto z=new Zombie(controller->scene);
             controller->addZombie(z);
             z->setPos(800,550);

         }
         if(secend==44||secend==47||secend==50||secend==51){
             auto z=new Zombie(controller->scene);
             controller->addZombie(z);

             z->setPos(800,700);

         }
         if(secend==46||secend==48||secend==50||secend==51){
             auto z=new Zombie(controller->scene);
             controller->addZombie(z);
             z->setPos(800,400);

         }
         if(secend==53){
             auto bz1=new BossZombie (controller->scene,5,12);
             controller->addBossZombie(bz1);
             bz1->setPos(800,400);
             auto bz2=new BossZombie (controller->scene,5,12);
             controller->addBossZombie(bz2);
             bz1->setPos(800,550);
             auto bz3=new BossZombie (controller->scene,5,12);
             controller->addBossZombie(bz3);
             bz3->setPos(800,700);

         }
         if(secend==62){
            clearScene();
             s3l3();
         }
     }catch(GameOver* e){
        auto g=new GameOvering();
        auto restart=new ReStart();
        controller->scene->addItem(restart);
    controller->scene->addItem(g);
    int timeOfGameOver=secend;
    if(secend==timeOfGameOver+4){
        s3l2();
    }
     }

}

void View::plusSecends3l3()
{
    try {
         ++secend;
         int a=rand();
         if(secend%10==0){
             auto sun=new Sun(controller->scene,controller->score,controller->holder,viewTimer);
              controller->score->setPlainText(QString::number(controller->score->getScore()));
         }
         if(secend==40||secend==48||secend==50||secend==47){
             auto z=new BossZombie (controller->scene,10,15);
             controller->addBossZombie(z);
             z->setPos(800,550);

         }
         if(secend==44||secend==47||secend==50||secend==51){
             auto z=new BossZombie (controller->scene,10,15);
             controller->addBossZombie(z);

             z->setPos(800,700);

         }
         if(secend==46||secend==48||secend==50||secend==51){
             auto z=new BossZombie (controller->scene,10,15);
             controller->addBossZombie(z);
             z->setPos(800,400);

         }
         if(secend==53){
             auto bz1=new BossZombie (controller->scene,10,15);
             controller->addBossZombie(bz1);
             bz1->setPos(800,400);
             auto bz2=new BossZombie (controller->scene,10,15);
             controller->addBossZombie(bz2);
             bz1->setPos(800,550);
             auto bz3=new BossZombie (controller->scene,10,15);
             controller->addBossZombie(bz2);
             bz3->setPos(800,700);

         }
         if(secend==58){
             controller->scene->clear();
             auto win=new QGraphicsTextItem();
             win->setPlainText("You Win!!");
             win->setDefaultTextColor(Qt::red);
             win->setFont(QFont("times",200));
             win->setPos(200,170);
             controller->scene->addItem(win);
         }
     }catch(GameOver e){
        auto g=new GameOvering();
        auto restart=new ReStart();
        controller->scene->addItem(restart);
    controller->scene->addItem(g);
    //g->setPos(200,170);
    int timeOfGameOver=secend;
    if(secend==timeOfGameOver+4){
        s3l3();
    }
     }

}

void View::clearScene()
{
    controller->zombies.clear();
    controller->bossZombies.clear();
    controller->balls.clear();
    controller->blocks.clear();
    controller->plants.clear();
    controller->setIsGameOver(false);
    controller->score=new Score();

}
